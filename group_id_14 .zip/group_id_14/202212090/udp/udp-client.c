#include <stdio.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <string.h>
#include <stdlib.h>

#define PORT 2000

typedef struct sockaddr sockaddr;

int main() {
    // create UDP socket and returns socket file descriptor
    int sockFD = socket(AF_INET, SOCK_DGRAM, 0);

    // if failed to create socket
    if(sockFD < 0) {
        printf("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    // assign ip address and port to the server address
    struct sockaddr_in serverAddress;
    serverAddress.sin_family = AF_INET;
    serverAddress.sin_port = htons(PORT);
    char * ipAddress = "127.0.0.1";
    int status = inet_pton(AF_INET, ipAddress, &serverAddress.sin_addr.s_addr);
    
    // if failed to assign ip address and port to the server address
    if(status < 0) {
        printf("Failed to assign ip address to the server address");
        exit(EXIT_FAILURE);
    }

    char *message = (char*) malloc(1024 * sizeof(char));
    char buffer[1024]; 

    while(1) {
        // get input from the user and send it to the server address
        printf("Enter string: ");
        size_t lineCount;
        size_t charCount = getline(&message, &lineCount, stdin);

        if(strcmp(message, "exit\n") == 0) {
            break;
        }
        
        sendto(sockFD, message, charCount, 0, (sockaddr*) &serverAddress, sizeof(serverAddress));

        // receive data from the server address and prints it to the console
        int serverAddressLen = sizeof(serverAddress);
        ssize_t recvCount = recvfrom(sockFD, buffer, 1024, 0, (sockaddr*) &serverAddress, &serverAddressLen);

        buffer[recvCount] = '\0';
        printf("Server: %s\n", buffer);
    }
    // close the socket using socket file descriptor
    close(sockFD);
    
    return 0;
}