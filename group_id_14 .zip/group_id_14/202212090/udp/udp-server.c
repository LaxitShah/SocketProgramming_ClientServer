#include <stdio.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <string.h>
#include <stdlib.h>

#define PORT 2000

typedef struct sockaddr sockaddr;

int main() {
    // create UDP socket and returns socket file descriptor
    int sockFD = socket(AF_INET, SOCK_DGRAM, 0);

    // if failed to create socket
    if(sockFD < 0) {
        printf("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    struct sockaddr_in serverAddress;
    serverAddress.sin_family = AF_INET;
    serverAddress.sin_port = htons(PORT);
    serverAddress.sin_addr.s_addr = INADDR_ANY;

    // assign address and port to the socket file descriptor
    int status = bind(sockFD, (sockaddr *)& serverAddress, sizeof(serverAddress));

    // if failed to bind socket to an address and port
    if(status < 0) {
        printf("Failed to bind socket to an address");
        exit(EXIT_FAILURE);
    }

    struct sockaddr_in clientAddress;
    int clientAddressLen = sizeof(clientAddress);

    char buffer[1024]; 
    char *message = (char*) malloc(1024 * sizeof(char));
    
    while(1) {
        // receive data from the client address and prints it to the console
        ssize_t recvCount = recvfrom(sockFD, buffer, 1024, 0, (sockaddr*) &clientAddress, &clientAddressLen);

        buffer[recvCount] = '\0';
        printf("Client: %s\n", buffer);

        // get input from the user and send it to the client address
        printf("Enter string: ");
        size_t lineCount;
        size_t charCount = getline(&message, &lineCount, stdin);

        sendto(sockFD, message, charCount, 0, (sockaddr*) &clientAddress, sizeof(clientAddress));
    }

    // close the socket using socket file descriptor
    close(sockFD);

    return 0;
}