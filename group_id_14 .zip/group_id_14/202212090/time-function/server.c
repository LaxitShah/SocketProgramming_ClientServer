#include <stdio.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

#define PORT 2000

int main() {
	time_t startTime, endTime;
	// start the timer
	time(&startTime);

	int sockFd = 0;

	// creating new IPV4 TCP socket
	sockFd = socket(AF_INET, SOCK_STREAM, 0);

	// if failed to create new socket
	if(sockFd < 0) {
		printf("socket creation failed");
		exit(EXIT_FAILURE);
	}

	int status = -1;
	int opt = 1;
	// Setting socket options for socket file descriptor
	status = setsockopt(sockFd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &opt, sizeof(opt));

	// if failed to set socket options	
	if(status < 0) {
		printf("Failed while setting socket options");
		exit(EXIT_FAILURE);
	}

	// Assigning IPV4, PORT and INADDR_ANY to the socket address
	struct sockaddr_in address;
	address.sin_family = AF_INET;
	address.sin_port = htons(PORT);
	address.sin_addr.s_addr = INADDR_ANY;

	// assigning socket address to the socket file descriptor
	status = bind(sockFd, (struct sockaddr*) & address, sizeof(address));

	// if failed to bind socket address to the file descriptor
	if(status < 0) {
		printf("socket bind failed");
		exit(EXIT_FAILURE);
	}

	// socket is open to listen on file descriptor up to 5 request connections
	status = listen(sockFd, 5);

	// if socket is failed to listen on file descriptor
	if(status < 0) {
		printf("socket listen failed");
		exit(EXIT_FAILURE);
	}
	// end the timer
	time(&endTime);
	time_t elapsed = endTime - startTime;

	printf("Server started in %ld seconds\n", elapsed);

	int clientSocketFd;
	struct sockaddr_in clientAddr;
	int addrLen = sizeof(clientAddr);

	// establishing connection between server and client
	// accept function will create new socket for the specified file descriptor and returns file descriptor of the new socket
	clientSocketFd = accept(sockFd, (struct sockaddr*) &clientAddr, &addrLen);

	if(clientSocketFd < 0) {
		printf("socket accept failed");
		exit(EXIT_FAILURE);
	}

	printf("Client connected successfully...\n");

	time_t sessionStart, sessionEnd;
	// start the session timer
	time(&sessionStart);

	while(1) {
		// getting input from the user and sending it to the client 
		
		char *message = (char *) malloc(1024 * sizeof(char));
		size_t messageTotalSize = 1024;
		
		printf("Enter string: ");
		ssize_t charCount = getline(&message, &messageTotalSize, stdin);
		
		if(strcmp(message, "exit\n") == 0) {
			break;
		}
		
		send(clientSocketFd, message, charCount, 0);
		
		// receiving data from the client and printing it to the console
		
		char buffer[1024] = {'\0'};
		ssize_t charCountRead = read(clientSocketFd, buffer, 1024);
		
		if(charCountRead <= 0) {
			break;
		}
		
		printf("Client: %s\n", buffer);
	}

	// closing client socket file descriptor
	close(clientSocketFd);

	// end the session timer
	time(&sessionEnd);
	elapsed = sessionEnd - sessionStart;

	printf("Client session time: %ld seconds\n", elapsed);

	// closing socket file descriptor
	close(sockFd);

	// shutdown socket file descriptor
	shutdown(sockFd, SHUT_RDWR);

	return 0;
}