#include <stdio.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

#define PORT 2000

int main() {
	time_t startTime, endTime;
	// start the timer
	time(&startTime);

	int sockFd, valread;

	// creating new IPV4 TCP socket
	sockFd = socket(AF_INET, SOCK_STREAM, 0);

	// if failed to create new socket
	if(sockFd < 0) {
		printf("socket creation failed");
		exit(EXIT_FAILURE);
	}
	
	int status = -1;

	// Assigning IPV4, PORT and ip-address to the server socket address
	struct sockaddr_in server;
	server.sin_family = AF_INET;
	server.sin_port = htons(PORT);
	char *ipAddress = "127.0.0.1";
	status = inet_pton(AF_INET, ipAddress, &server.sin_addr.s_addr);

	// if failed to assign ip address to the server socket address
	if(status < 0) {
		printf("Failed to assign ip address to the server socket address");
		exit(EXIT_FAILURE);
	}

	// connects socket file descriptor to the server 
	status = connect(sockFd, (struct sockaddr*) &server, sizeof(server));

	// if socket file descriptor failed to connect to the specified server
	if(status < 0) {
		printf("Failed to connect to the server");
		exit(EXIT_FAILURE);
	}

	// end the timer
	time(&endTime);
	time_t elapsed = endTime - startTime;

	printf("Successfully connected to the server in %ld seconds...\n", elapsed);

	time_t sessionStart, sessionEnd;
	time(&sessionStart);

	while(1) {
		// receiving data from the server and printing it to the console	
		
		char buffer[1024] = {'\0'};
		ssize_t charCountRead = read(sockFd, buffer, 1024);
		
		if(charCountRead == 0) {
			break;
		}
		printf("Server: %s\n", buffer);
		
		// getting input from the user and sending it to the server
		
		printf("Enter string: ");
		
		char *message = (char *) malloc(1024 * sizeof(char));
		size_t	messageTotalSize = 1024;
		ssize_t charCount = getline(&message, &messageTotalSize, stdin);
		
		if(strcmp(message, "exit\n") == 0) {
			break;
		}

		send(sockFd, message, charCount, 0);
		printf("\n");
	}

	// closing socket file descriptor
	close(sockFd);

	time(&sessionEnd);
	elapsed = sessionEnd - sessionStart;

	printf("Session time: %ld seconds\n", elapsed);
	
	return 0;
}

